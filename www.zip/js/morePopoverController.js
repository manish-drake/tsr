angular.module('App')
    .controller('morePopoverController', function ($scope) {

        $scope.button2_Click = function () {
            this.button2.clicked = !this.button2.clicked
        }
    });